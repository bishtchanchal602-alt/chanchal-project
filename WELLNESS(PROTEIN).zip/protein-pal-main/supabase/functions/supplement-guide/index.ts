import { corsHeaders, callGemini, jsonResponse, parseJsonWithRetry } from "../_shared/ai.ts";

const SYSTEM = `You are FitProtein Coach, a sports nutritionist providing supplement guidance for Indian users.
Rules:
1. Suggest only well-researched supplements relevant to the user's goal & gaps.
2. ALWAYS include natural food alternatives for each supplement.
3. Use Indian brand price ranges (2024 INR per month).
4. Never recommend prescription drugs, hormones, or banned substances.
5. Note that this is general guidance, not medical advice.
6. Respond ONLY with valid JSON. No markdown.`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { userContext } = await req.json();
    const user = `User profile:
${JSON.stringify(userContext, null, 2)}

Recommend 4-6 supplements personalized to this user's training goal, diet, and protein gap.
For each: include a natural food alternative, why it helps THIS user, dosage, timing, monthly cost in INR, and priority (Essential | Helpful | Optional).
Only suggest supplements compatible with: ${(userContext.proteinPreferences || []).join(", ")} and restrictions: ${(userContext.dietaryRestrictions || []).join(", ") || "None"}.

Return ONLY this JSON:
{
  "supplements": [
    {
      "name":"",
      "priority":"Essential | Helpful | Optional",
      "whyForYou":"",
      "dosage":"",
      "timing":"",
      "monthlyCostInr":0,
      "naturalAlternatives":[""],
      "indianBrands":[""],
      "cautions":""
    }
  ],
  "summary":"",
  "totalMonthlyEssentialCost":0
}`;

    const r = await parseJsonWithRetry(() => callGemini({ system: SYSTEM, user, json: true }));
    if (!r.ok) return jsonResponse({ error: r.error }, r.status);
    return jsonResponse(r.data);
  } catch (e) {
    console.error("supplement-guide error:", e);
    return jsonResponse({ error: e instanceof Error ? e.message : "Unknown error" }, 500);
  }
});
