import { corsHeaders, callGemini, jsonResponse, parseJsonWithRetry } from "../_shared/ai.ts";

const SYSTEM = `You are FitProtein Coach analyzing a user's recent progress data. Be specific, encouraging, actionable. No generic platitudes.
Respond ONLY with valid JSON. No markdown.`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { userContext, weightLogs, mealLogs, period } = await req.json();
    const periodLabel = period === "weekly" ? "30-day weekly" : "7-day daily";
    const user = `User: ${JSON.stringify(userContext, null, 2)}
Recent weight logs (latest first): ${JSON.stringify(weightLogs)}
Recent daily protein totals (latest first): ${JSON.stringify(mealLogs)}

Analyze the user's ${periodLabel} progress: protein adherence, weight movement vs goal (${userContext.trainingGoal}), and trend direction.
${period === "weekly" ? "Focus on weekly patterns, multi-week trends, and habit consistency." : "Focus on the most recent week and short-term momentum."}
Return ONLY this JSON:
{
  "headline":"",
  "adherencePct":0,
  "weightTrend":"gaining | losing | maintaining",
  "weightChangeKg":0,
  "wins":[""],
  "warnings":[""],
  "nextActions":[""]
}`;

    const r = await parseJsonWithRetry(() => callGemini({ system: SYSTEM, user, json: true }));
    if (!r.ok) return jsonResponse({ error: r.error }, r.status);
    return jsonResponse(r.data);
  } catch (e) {
    console.error("progress-insights error:", e);
    return jsonResponse({ error: e instanceof Error ? e.message : "Unknown error" }, 500);
  }
});
