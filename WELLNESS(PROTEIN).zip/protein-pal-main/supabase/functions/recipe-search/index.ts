import { corsHeaders, callGemini, jsonResponse, parseJsonWithRetry } from "../_shared/ai.ts";

const SYSTEM = `You are FitProtein Coach, an Indian sports nutrition expert.
Rules:
1. Suggest only Indian, budget-friendly high-protein recipes.
2. Each recipe: 25-50g protein.
3. Respect user's protein preferences and dietary restrictions strictly.
4. Use realistic 2024 INR prices.
5. Respond ONLY with valid JSON matching the schema. No markdown, no prose.`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { query, userContext } = await req.json();
    const user = `User profile:
${JSON.stringify(userContext, null, 2)}

User searched for: "${query}"

Generate 4 personalized Indian high-protein recipes matching the search. Only use proteins from: ${(userContext.proteinPreferences || []).join(", ")}.
Respect restrictions: ${(userContext.dietaryRestrictions || []).join(", ") || "None"}.
Each recipe ≤ ${userContext.maxCookTime || "30 minutes"}.

Return ONLY this JSON:
{
  "recipes": [
    {
      "name": "",
      "tagline": "",
      "totalProtein": 0,
      "totalCalories": 0,
      "estimatedCost": 0,
      "cookTime": 0,
      "difficulty": "Easy | Medium | Hard",
      "ingredients": [{"item":"","quantity":"","proteinContribution":0}],
      "steps": [""],
      "proTip": "",
      "whyThis": ""
    }
  ]
}`;

    const r = await parseJsonWithRetry(() => callGemini({ system: SYSTEM, user, json: true }));
    if (!r.ok) return jsonResponse({ error: r.error }, r.status);
    return jsonResponse(r.data);
  } catch (e) {
    console.error("recipe-search error:", e);
    return jsonResponse({ error: e instanceof Error ? e.message : "Unknown error" }, 500);
  }
});
