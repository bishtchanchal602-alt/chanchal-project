// Shared helper for calling Lovable AI Gateway with Gemini
export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

export async function callGemini(opts: {
  system: string;
  user: string;
  json?: boolean;
  model?: string;
}): Promise<{ ok: true; content: string } | { ok: false; status: number; error: string }> {
  const key = Deno.env.get("LOVABLE_API_KEY");
  if (!key) return { ok: false, status: 500, error: "LOVABLE_API_KEY not configured" };

  const body: Record<string, unknown> = {
    model: opts.model || "google/gemini-2.5-flash",
    messages: [
      { role: "system", content: opts.system },
      { role: "user", content: opts.user },
    ],
  };
  if (opts.json) body.response_format = { type: "json_object" };

  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (res.status === 429) return { ok: false, status: 429, error: "Rate limit reached. Try again in a moment." };
  if (res.status === 402) return { ok: false, status: 402, error: "AI credits exhausted. Add credits in Workspace settings." };
  if (!res.ok) {
    const t = await res.text();
    console.error("AI gateway error:", res.status, t);
    return { ok: false, status: 500, error: "AI request failed" };
  }
  const data = await res.json();
  return { ok: true, content: data.choices?.[0]?.message?.content ?? "" };
}

export function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

export async function parseJsonWithRetry(
  call: () => Promise<{ ok: true; content: string } | { ok: false; status: number; error: string }>,
): Promise<{ ok: true; data: unknown } | { ok: false; status: number; error: string }> {
  let last = await call();
  if (!last.ok) return last;
  try { return { ok: true, data: JSON.parse(last.content) }; } catch { /* retry */ }
  last = await call();
  if (!last.ok) return last;
  try { return { ok: true, data: JSON.parse(last.content) }; } catch {
    return { ok: false, status: 500, error: "AI returned invalid JSON. Try again." };
  }
}
