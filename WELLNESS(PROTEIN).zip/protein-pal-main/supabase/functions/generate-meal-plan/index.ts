// Lovable AI Gateway — daily meal plan generator (Gemini)
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const SYSTEM_PROMPT = `You are FitProtein Coach, an expert sports nutritionist specializing in Indian, budget-friendly high-protein meals.
Hard rules — never break:
1. Max 40-50g protein per meal, min 20g.
2. Max 3 whole eggs + 3 whites per meal.
3. Soya chunks max 60g dry per meal.
4. Chicken max 200g cooked per meal. Paneer max 150g per meal.
5. Each meal = 1 protein + 1 carb + 1 healthy fat.
6. Stay within the user's daily budget (INR), cook time, dietary restrictions, and protein preferences. Never suggest excluded proteins.
7. Use Indian-market ingredients with realistic 2024 INR prices.
8. Respond ONLY with valid JSON matching the requested schema. No markdown, no prose.`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { userContext } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const userPrompt = `User profile:
${JSON.stringify(userContext, null, 2)}

Generate a complete one-day high-protein Indian meal plan. Include exactly ${userContext.mealsPerDay} meals timed around their ${userContext.workoutTime} workout (include pre/post-workout if relevant).

Total daily protein must reach ~${userContext.dailyProteinTarget}g. Total cost under ₹${userContext.dailyBudget}. Each recipe under ${userContext.maxCookTime}.
Only use protein sources from: ${(userContext.proteinPreferences || []).join(", ")}.
Respect restrictions: ${(userContext.dietaryRestrictions || []).join(", ") || "None"}.
Goal: ${userContext.trainingGoal}.
User has eaten ${userContext.todayProteinConsumed || 0}g protein today — adjust remaining meals.

Return ONLY this JSON (no markdown):
{
  "mealPlan": [
    {
      "mealType": "Breakfast | Pre-Workout | Lunch | Post-Workout | Dinner | Evening Snack",
      "time": "7:30 AM",
      "recipeName": "",
      "proteinSources": [""],
      "totalProtein": 0,
      "totalCalories": 0,
      "estimatedCost": 0,
      "cookTime": 0,
      "ingredients": [{"item":"","quantity":"","proteinContribution":0}],
      "steps": [""],
      "proTip": "",
      "goalReason": ""
    }
  ],
  "totalDayProtein": 0,
  "totalDayCost": 0,
  "totalDayCalories": 0,
  "aiNote": ""
}`;

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPrompt },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (aiRes.status === 429) {
      return new Response(
        JSON.stringify({ error: "Rate limit reached. Try again in a moment." }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }
    if (aiRes.status === 402) {
      return new Response(
        JSON.stringify({ error: "AI credits exhausted. Add credits in Workspace settings." }),
        { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }
    if (!aiRes.ok) {
      const t = await aiRes.text();
      console.error("AI gateway error:", aiRes.status, t);
      return new Response(JSON.stringify({ error: "Failed to generate plan" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await aiRes.json();
    const text = data.choices?.[0]?.message?.content ?? "{}";
    let plan;
    try {
      plan = JSON.parse(text);
    } catch {
      // retry once with a stricter nudge
      console.error("First JSON parse failed, raw:", text);
      return new Response(JSON.stringify({ error: "AI returned invalid format. Try again." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify(plan), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("generate-meal-plan error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
