import { corsHeaders, jsonResponse } from "../_shared/ai.ts";

const SYSTEM = `You are FitProtein Coach — friendly, expert Indian sports nutritionist. The user is chatting with you.
- Use the user's profile (goals, weight, preferences, restrictions, budget) in every reply.
- Be concise (2-5 sentences typically). Use bullet points for lists.
- Suggest only Indian, budget-friendly options compatible with their preferences.
- Never give medical advice — refer to a doctor for medical issues.
- No markdown headers. Plain text or short bullets only.`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { userContext, history, message } = await req.json();
    const sys = `${SYSTEM}

User profile:
${JSON.stringify(userContext, null, 2)}`;

    const messages = [
      { role: "system", content: sys },
      ...((history as Array<{ role: string; content: string }>) || []).slice(-12),
      { role: "user", content: message },
    ];

    const key = Deno.env.get("LOVABLE_API_KEY");
    if (!key) return jsonResponse({ error: "LOVABLE_API_KEY not configured" }, 500);

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: "google/gemini-2.5-flash", messages }),
    });

    if (res.status === 429) return jsonResponse({ error: "Rate limit reached. Try again in a moment." }, 429);
    if (res.status === 402) return jsonResponse({ error: "AI credits exhausted." }, 402);
    if (!res.ok) {
      console.error("chat error:", res.status, await res.text());
      return jsonResponse({ error: "Chat failed" }, 500);
    }
    const data = await res.json();
    const reply = data.choices?.[0]?.message?.content ?? "";
    return jsonResponse({ reply });
  } catch (e) {
    console.error("coach-chat error:", e);
    return jsonResponse({ error: e instanceof Error ? e.message : "Unknown error" }, 500);
  }
});

