import { corsHeaders, callGemini, jsonResponse, parseJsonWithRetry } from "../_shared/ai.ts";

const SYSTEM = `You are FitProtein Coach, an Indian sports nutrition expert specializing in pre/post-workout fueling.
Rules:
1. Pre-workout: easy carbs + light protein, 30-60 min before training.
2. Post-workout: 25-40g fast protein + carbs within 45 min.
3. Use Indian, budget-friendly options matching user's protein preferences.
4. Realistic 2024 INR prices.
5. Respond ONLY with valid JSON. No markdown.`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { userContext } = await req.json();
    const user = `User profile:
${JSON.stringify(userContext, null, 2)}

Generate 3 pre-workout and 3 post-workout snack/meal options personalized to this user.
Only use proteins from: ${(userContext.proteinPreferences || []).join(", ")}.
Respect restrictions: ${(userContext.dietaryRestrictions || []).join(", ") || "None"}.
Workout time: ${userContext.workoutTime}. Goal: ${userContext.trainingGoal}.

Return ONLY this JSON:
{
  "pre": [
    {"name":"","timing":"e.g. 45 min before","protein":0,"calories":0,"cost":0,"prepTime":0,"ingredients":[""],"why":""}
  ],
  "post": [
    {"name":"","timing":"e.g. within 30 min after","protein":0,"calories":0,"cost":0,"prepTime":0,"ingredients":[""],"why":""}
  ],
  "hydrationTip": "",
  "aiNote": ""
}`;

    const r = await parseJsonWithRetry(() => callGemini({ system: SYSTEM, user, json: true }));
    if (!r.ok) return jsonResponse({ error: r.error }, r.status);
    return jsonResponse(r.data);
  } catch (e) {
    console.error("workout-nutrition error:", e);
    return jsonResponse({ error: e instanceof Error ? e.message : "Unknown error" }, 500);
  }
});
