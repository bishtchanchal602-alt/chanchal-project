import { corsHeaders, callGemini, jsonResponse, parseJsonWithRetry } from "../_shared/ai.ts";

const SYSTEM = `You are FitProtein Coach. Generate a 7-day Indian high-protein meal plan with a consolidated grocery list.
Hard rules:
1. Each day hits the user's daily protein target ±10%.
2. Variety across days — never repeat the same recipe twice.
3. Stay within daily budget. Realistic 2024 INR prices.
4. Use only allowed protein sources & restrictions.
5. Respond ONLY with valid JSON. No markdown.`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { userContext } = await req.json();
    const user = `User profile:
${JSON.stringify(userContext, null, 2)}

Generate a 7-day plan (Mon-Sun) with ${userContext.mealsPerDay} meals each day. Daily protein target ${userContext.dailyProteinTarget}g. Daily budget ₹${userContext.dailyBudget}. Cook time ≤ ${userContext.maxCookTime}.
Only proteins: ${(userContext.proteinPreferences || []).join(", ")}.
Restrictions: ${(userContext.dietaryRestrictions || []).join(", ") || "None"}.

Return ONLY this JSON:
{
  "days":[
    {"day":"Monday","meals":[{"mealType":"","recipeName":"","totalProtein":0,"totalCalories":0,"estimatedCost":0}],"dayProtein":0,"dayCost":0}
  ],
  "groceryList":[{"item":"","quantity":"","estimatedCost":0,"category":"Proteins | Grains | Dairy | Veggies | Pantry"}],
  "totalWeekCost":0,
  "aiNote":""
}`;

    const r = await parseJsonWithRetry(() => callGemini({ system: SYSTEM, user, json: true }));
    if (!r.ok) return jsonResponse({ error: r.error }, r.status);
    return jsonResponse(r.data);
  } catch (e) {
    console.error("weekly-plan error:", e);
    return jsonResponse({ error: e instanceof Error ? e.message : "Unknown error" }, 500);
  }
});
