-- Cached AI generations per user per kind
CREATE TABLE public.cached_content (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  kind TEXT NOT NULL,
  data JSONB NOT NULL,
  generated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (user_id, kind)
);

ALTER TABLE public.cached_content ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users own cached content"
  ON public.cached_content
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Recipe search history per user
CREATE TABLE public.recipe_searches (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  query TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.recipe_searches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users own recipe searches"
  ON public.recipe_searches
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX idx_recipe_searches_user_created ON public.recipe_searches(user_id, created_at DESC);