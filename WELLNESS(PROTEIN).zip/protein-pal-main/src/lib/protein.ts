// Protein & calorie calculation engine
export type Goal = "Stay Fit" | "Build Muscle" | "Bulking" | "Lose Weight";

export function calcDailyProtein(weightKg: number, goal: Goal): number {
  const multipliers: Record<Goal, number> = {
    "Stay Fit": 0.9,
    "Build Muscle": 1.8,
    Bulking: 2.0,
    "Lose Weight": 1.6,
  };
  return Math.round(weightKg * (multipliers[goal] ?? 1.6));
}

export function calcDailyCalories(weightKg: number, goal: Goal): number {
  // Simple maintenance approx then adjust for goal
  const maintenance = weightKg * 30;
  switch (goal) {
    case "Bulking":
      return Math.round(maintenance + 400);
    case "Build Muscle":
      return Math.round(maintenance + 200);
    case "Lose Weight":
      return Math.round(maintenance - 400);
    default:
      return Math.round(maintenance);
  }
}
