import { supabase } from "@/integrations/supabase/client";

export type CacheKind = "workout" | "weekly" | "supplements" | "progress_daily" | "progress_weekly";

export async function loadCached<T>(userId: string, kind: CacheKind): Promise<{ data: T; generatedAt: string } | null> {
  const { data } = await supabase
    .from("cached_content")
    .select("data,generated_at")
    .eq("user_id", userId)
    .eq("kind", kind)
    .maybeSingle();
  if (!data) return null;
  return { data: data.data as T, generatedAt: data.generated_at as string };
}

export async function saveCached<T>(userId: string, kind: CacheKind, data: T) {
  await supabase
    .from("cached_content")
    .upsert(
      [{ user_id: userId, kind, data: data as never, generated_at: new Date().toISOString() }],
      { onConflict: "user_id,kind" }
    );
}

/**
 * Compute current streak: number of consecutive days (ending today or yesterday)
 * where total protein >= target.
 */
export function computeStreak(dailyTotals: Record<string, number>, target: number): number {
  if (!target) return 0;
  let streak = 0;
  // start from today; if today not yet hit, start from yesterday so streak survives mid-day
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const todayKey = start.toISOString().slice(0, 10);
  if ((dailyTotals[todayKey] || 0) < target) {
    start.setDate(start.getDate() - 1);
  }
  // walk backwards
  for (let i = 0; i < 365; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    if ((dailyTotals[key] || 0) >= target) streak++;
    else break;
  }
  return streak;
}
