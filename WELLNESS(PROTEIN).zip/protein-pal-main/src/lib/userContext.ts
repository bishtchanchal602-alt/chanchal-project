import { supabase } from "@/integrations/supabase/client";

export type UserContext = {
  name: string | null;
  age: number | null;
  sex: string | null;
  currentWeight: number | null;
  targetWeight: number | null;
  height: number | null;
  trainingGoal: string | null;
  workoutTime: string | null;
  workoutDays: number | null;
  workoutTypes: string[] | null;
  proteinPreferences: string[] | null;
  dietaryRestrictions: string[] | null;
  dailyBudget: number | null;
  maxCookTime: string | null;
  mealsPerDay: number | null;
  dailyProteinTarget: number | null;
  proteinPerMeal: number | null;
  dailyCalorieTarget: number | null;
  todayProteinConsumed?: number;
};

export async function loadUserContext(): Promise<{ userId: string; ctx: UserContext } | null> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) return null;
  const { data: p } = await supabase.from("profiles").select("*").eq("id", session.user.id).maybeSingle();
  if (!p) return null;
  return {
    userId: session.user.id,
    ctx: {
      name: p.full_name,
      age: p.age,
      sex: p.sex,
      currentWeight: p.current_weight,
      targetWeight: p.target_weight,
      height: p.height,
      trainingGoal: p.training_goal,
      workoutTime: p.workout_time,
      workoutDays: p.workout_days,
      workoutTypes: p.workout_types,
      proteinPreferences: p.protein_preferences,
      dietaryRestrictions: p.dietary_restrictions,
      dailyBudget: p.daily_budget ? Number(p.daily_budget) : null,
      maxCookTime: p.max_cook_time,
      mealsPerDay: p.meals_per_day,
      dailyProteinTarget: p.daily_protein_target ? Number(p.daily_protein_target) : null,
      proteinPerMeal: p.protein_per_meal ? Number(p.protein_per_meal) : null,
      dailyCalorieTarget: p.daily_calorie_target ? Number(p.daily_calorie_target) : null,
    },
  };
}
