export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      cached_content: {
        Row: {
          data: Json
          generated_at: string
          id: string
          kind: string
          user_id: string
        }
        Insert: {
          data: Json
          generated_at?: string
          id?: string
          kind: string
          user_id: string
        }
        Update: {
          data?: Json
          generated_at?: string
          id?: string
          kind?: string
          user_id?: string
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          role: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          role: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          role?: string
          user_id?: string
        }
        Relationships: []
      }
      daily_plans: {
        Row: {
          created_at: string
          id: string
          plan_data: Json
          plan_date: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          plan_data: Json
          plan_date?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          plan_data?: Json
          plan_date?: string
          user_id?: string
        }
        Relationships: []
      }
      meal_logs: {
        Row: {
          calories: number | null
          cost: number | null
          created_at: string
          id: string
          log_date: string
          meal_name: string
          protein_grams: number
          source: string | null
          user_id: string
        }
        Insert: {
          calories?: number | null
          cost?: number | null
          created_at?: string
          id?: string
          log_date?: string
          meal_name: string
          protein_grams?: number
          source?: string | null
          user_id: string
        }
        Update: {
          calories?: number | null
          cost?: number | null
          created_at?: string
          id?: string
          log_date?: string
          meal_name?: string
          protein_grams?: number
          source?: string | null
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          age: number | null
          created_at: string
          current_weight: number | null
          daily_budget: number | null
          daily_calorie_target: number | null
          daily_protein_target: number | null
          dietary_restrictions: string[] | null
          email: string | null
          full_name: string | null
          height: number | null
          id: string
          max_cook_time: string | null
          meals_per_day: number | null
          onboarding_completed: boolean | null
          protein_per_meal: number | null
          protein_preferences: string[] | null
          sex: string | null
          target_weight: number | null
          training_goal: string | null
          unit_height: string | null
          unit_weight: string | null
          updated_at: string
          weeks_active: number | null
          workout_days: number | null
          workout_duration: string | null
          workout_time: string | null
          workout_types: string[] | null
        }
        Insert: {
          age?: number | null
          created_at?: string
          current_weight?: number | null
          daily_budget?: number | null
          daily_calorie_target?: number | null
          daily_protein_target?: number | null
          dietary_restrictions?: string[] | null
          email?: string | null
          full_name?: string | null
          height?: number | null
          id: string
          max_cook_time?: string | null
          meals_per_day?: number | null
          onboarding_completed?: boolean | null
          protein_per_meal?: number | null
          protein_preferences?: string[] | null
          sex?: string | null
          target_weight?: number | null
          training_goal?: string | null
          unit_height?: string | null
          unit_weight?: string | null
          updated_at?: string
          weeks_active?: number | null
          workout_days?: number | null
          workout_duration?: string | null
          workout_time?: string | null
          workout_types?: string[] | null
        }
        Update: {
          age?: number | null
          created_at?: string
          current_weight?: number | null
          daily_budget?: number | null
          daily_calorie_target?: number | null
          daily_protein_target?: number | null
          dietary_restrictions?: string[] | null
          email?: string | null
          full_name?: string | null
          height?: number | null
          id?: string
          max_cook_time?: string | null
          meals_per_day?: number | null
          onboarding_completed?: boolean | null
          protein_per_meal?: number | null
          protein_preferences?: string[] | null
          sex?: string | null
          target_weight?: number | null
          training_goal?: string | null
          unit_height?: string | null
          unit_weight?: string | null
          updated_at?: string
          weeks_active?: number | null
          workout_days?: number | null
          workout_duration?: string | null
          workout_time?: string | null
          workout_types?: string[] | null
        }
        Relationships: []
      }
      recipe_searches: {
        Row: {
          created_at: string
          id: string
          query: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          query: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          query?: string
          user_id?: string
        }
        Relationships: []
      }
      weight_logs: {
        Row: {
          created_at: string
          id: string
          log_date: string
          user_id: string
          weight: number
        }
        Insert: {
          created_at?: string
          id?: string
          log_date?: string
          user_id: string
          weight: number
        }
        Update: {
          created_at?: string
          id?: string
          log_date?: string
          user_id?: string
          weight?: number
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
