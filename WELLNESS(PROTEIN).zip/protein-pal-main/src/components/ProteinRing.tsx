type Props = { value: number; target: number };

export function ProteinRing({ value, target }: Props) {
  const pct = target > 0 ? Math.min(100, (value / target) * 100) : 0;
  const radius = 56;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (pct / 100) * circumference;
  const color = pct >= 90 ? "var(--primary)" : pct >= 60 ? "var(--warning)" : "var(--accent)";

  return (
    <div className="relative h-36 w-36 shrink-0">
      <svg className="h-full w-full -rotate-90" viewBox="0 0 140 140">
        <circle cx="70" cy="70" r={radius} fill="none" stroke="var(--muted)" strokeWidth="10" />
        <circle
          cx="70" cy="70" r={radius} fill="none"
          stroke={color}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 0.6s ease, stroke 0.3s" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-3xl font-bold" style={{ color }}>{Math.round(pct)}%</span>
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Protein</span>
      </div>
    </div>
  );
}
