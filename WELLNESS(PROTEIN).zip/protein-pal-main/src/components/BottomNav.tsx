import { Link, useLocation } from "@tanstack/react-router";
import { Home, Search, Dumbbell, Pill, CalendarDays, TrendingUp } from "lucide-react";

const items = [
  { to: "/dashboard", label: "Today", icon: Home },
  { to: "/recipes", label: "Recipes", icon: Search },
  { to: "/workout", label: "Workout", icon: Dumbbell },
  { to: "/supplements", label: "Supps", icon: Pill },
  { to: "/weekly", label: "Weekly", icon: CalendarDays },
  { to: "/progress", label: "Progress", icon: TrendingUp },
] as const;

export function BottomNav() {
  const { pathname } = useLocation();
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-20 border-t border-border bg-background/95 backdrop-blur">
      <div className="mx-auto flex max-w-4xl items-center justify-between px-2 py-1.5">
        {items.map(({ to, label, icon: Icon }) => {
          const active = pathname === to;
          return (
            <Link
              key={to}
              to={to}
              className={`flex flex-1 flex-col items-center gap-0.5 rounded-lg px-2 py-1.5 text-[10px] font-medium transition ${
                active ? "text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className={`h-5 w-5 ${active ? "text-primary" : ""}`} />
              {label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
