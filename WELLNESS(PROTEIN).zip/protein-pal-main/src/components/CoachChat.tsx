import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { loadUserContext, type UserContext } from "@/lib/userContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageCircle, X, Send, Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";

type Msg = { id?: string; role: "user" | "assistant"; content: string };

export function CoachChat() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [ctx, setCtx] = useState<UserContext | null>(null);
  const [userId, setUserId] = useState<string>("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    loadUserContext().then(async (r) => {
      if (!r) return;
      setCtx(r.ctx);
      setUserId(r.userId);
      const { data } = await supabase
        .from("chat_messages")
        .select("id,role,content")
        .eq("user_id", r.userId)
        .order("created_at", { ascending: true })
        .limit(50);
      setMessages((data as Msg[]) || []);
    });
  }, [open]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, open]);

  const send = async () => {
    const text = input.trim();
    if (!text || !ctx || !userId || sending) return;
    setSending(true);
    setInput("");
    const userMsg: Msg = { role: "user", content: text };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    try {
      await supabase.from("chat_messages").insert({ user_id: userId, role: "user", content: text });
      const { data, error } = await supabase.functions.invoke("coach-chat", {
        body: { userContext: ctx, history: messages, message: text },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      const reply: Msg = { role: "assistant", content: data.reply || "..." };
      setMessages([...newMessages, reply]);
      await supabase.from("chat_messages").insert({ user_id: userId, role: "assistant", content: reply.content });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Chat failed");
    } finally {
      setSending(false);
    }
  };

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-20 right-4 z-30 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/30 transition hover:scale-105"
        aria-label="Open coach chat"
      >
        <MessageCircle className="h-6 w-6" />
      </button>
    );
  }

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-background/60 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="flex h-[85vh] w-full max-w-md flex-col rounded-t-2xl border border-border bg-card shadow-2xl sm:rounded-2xl">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            <div>
              <p className="text-sm font-bold">Coach</p>
              <p className="text-[10px] text-muted-foreground">Powered by Gemini</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={() => setOpen(false)}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto p-4">
          {messages.length === 0 && (
            <div className="space-y-3 py-8 text-center text-sm">
              <Sparkles className="mx-auto h-8 w-8 text-primary" />
              <p className="font-medium">Ask me anything</p>
              <p className="text-xs text-muted-foreground">"What should I eat post-workout?"<br/>"Best veg protein under ₹50?"<br/>"Help me hit my target today."</p>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] whitespace-pre-wrap rounded-2xl px-3 py-2 text-sm ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>
                {m.content}
              </div>
            </div>
          ))}
          {sending && (
            <div className="flex justify-start">
              <div className="rounded-2xl bg-muted px-3 py-2"><Loader2 className="h-4 w-4 animate-spin text-primary" /></div>
            </div>
          )}
        </div>

        <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex gap-2 border-t border-border p-3">
          <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask your coach…" disabled={sending} className="bg-background" />
          <Button type="submit" disabled={sending || !input.trim()} className="bg-primary text-primary-foreground hover:opacity-90">
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </div>
  );
}
