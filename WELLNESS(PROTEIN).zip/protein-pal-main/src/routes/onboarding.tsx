import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { calcDailyCalories, calcDailyProtein, type Goal } from "@/lib/protein";
import { toast } from "sonner";
import { ArrowLeft, ArrowRight, Loader2, Activity, Dumbbell, Flame, TrendingDown, Check } from "lucide-react";

export const Route = createFileRoute("/onboarding")({
  component: Onboarding,
});

type Form = {
  full_name: string;
  age: number;
  sex: string;
  current_weight: number;
  target_weight: number;
  height: number;
  training_goal: Goal;
  workout_days: number;
  workout_duration: string;
  workout_types: string[];
  workout_time: string;
  protein_preferences: string[];
  daily_budget: number;
  max_cook_time: string;
  meals_per_day: number;
  dietary_restrictions: string[];
};

const GOALS: { value: Goal; icon: React.ReactNode; desc: string }[] = [
  { value: "Stay Fit", icon: <Activity className="h-6 w-6" />, desc: "Maintain a healthy body" },
  { value: "Build Muscle", icon: <Dumbbell className="h-6 w-6" />, desc: "Lean muscle gain" },
  { value: "Bulking", icon: <Flame className="h-6 w-6" />, desc: "Maximum size & strength" },
  { value: "Lose Weight", icon: <TrendingDown className="h-6 w-6" />, desc: "Cut fat, keep muscle" },
];

const WORKOUT_TYPES = ["Weight Training", "Cardio", "HIIT", "Yoga", "Calisthenics", "Mixed"];
const WORKOUT_TIMES = ["Morning", "Afternoon", "Evening", "Night"];
const DURATIONS = ["30 min", "45 min", "60 min", "90 min+"];
const PROTEIN_PREFS = [
  { v: "Plant-Based", e: "🌱" }, { v: "Eggs", e: "🥚" }, { v: "Fish & Seafood", e: "🐟" },
  { v: "Chicken", e: "🍗" }, { v: "Red Meat", e: "🥩" }, { v: "Dairy", e: "🥛" },
  { v: "Grains & Legumes", e: "🌾" },
];
const BUDGETS = [100, 200, 400, 600];
const COOK_TIMES = ["Under 10 min", "10–20 min", "20–40 min", "40+ min"];
const RESTRICTIONS = ["None", "Gluten-Free", "Lactose-Intolerant", "Diabetic"];

function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [form, setForm] = useState<Form>({
    full_name: "",
    age: 25,
    sex: "Male",
    current_weight: 70,
    target_weight: 75,
    height: 175,
    training_goal: "Build Muscle",
    workout_days: 4,
    workout_duration: "60 min",
    workout_types: ["Weight Training"],
    workout_time: "Evening",
    protein_preferences: ["Eggs", "Chicken", "Dairy"],
    daily_budget: 200,
    max_cook_time: "20–40 min",
    meals_per_day: 4,
    dietary_restrictions: ["None"],
  });

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) { navigate({ to: "/auth" }); return; }
      setUserId(data.session.user.id);
      setForm((f) => ({ ...f, full_name: (data.session?.user.user_metadata?.full_name as string) || "" }));
    });
  }, [navigate]);

  const update = <K extends keyof Form>(k: K, v: Form[K]) => setForm((f) => ({ ...f, [k]: v }));

  const toggleArr = (k: "workout_types" | "protein_preferences" | "dietary_restrictions", val: string) => {
    setForm((f) => {
      const arr = f[k];
      return { ...f, [k]: arr.includes(val) ? arr.filter((x) => x !== val) : [...arr, val] };
    });
  };

  const total = 6;
  const progress = ((step + 1) / total) * 100;

  const submit = async () => {
    if (!userId) return;
    setSaving(true);
    try {
      const dailyProtein = calcDailyProtein(form.current_weight, form.training_goal);
      const dailyCalories = calcDailyCalories(form.current_weight, form.training_goal);
      const proteinPerMeal = Math.round(dailyProtein / form.meals_per_day);

      const { error } = await supabase.from("profiles").update({
        full_name: form.full_name,
        age: form.age,
        sex: form.sex,
        current_weight: form.current_weight,
        target_weight: form.target_weight,
        height: form.height,
        training_goal: form.training_goal,
        workout_days: form.workout_days,
        workout_duration: form.workout_duration,
        workout_types: form.workout_types,
        workout_time: form.workout_time,
        protein_preferences: form.protein_preferences,
        daily_budget: form.daily_budget,
        max_cook_time: form.max_cook_time,
        meals_per_day: form.meals_per_day,
        dietary_restrictions: form.dietary_restrictions,
        daily_protein_target: dailyProtein,
        daily_calorie_target: dailyCalories,
        protein_per_meal: proteinPerMeal,
        onboarding_completed: true,
      }).eq("id", userId);
      if (error) throw error;
      toast.success("Profile saved! Generating your plan…");
      navigate({ to: "/dashboard" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to save");
    } finally {
      setSaving(false);
    }
  };

  const next = () => setStep((s) => Math.min(s + 1, total - 1));
  const back = () => setStep((s) => Math.max(s - 1, 0));

  return (
    <div className="min-h-screen bg-background px-4 py-8">
      <div className="mx-auto max-w-2xl">
        <div className="mb-8">
          <div className="mb-2 flex items-center justify-between text-sm text-muted-foreground">
            <span>Step {step + 1} of {total}</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-muted">
            <div className="h-full bg-primary transition-all duration-300" style={{ width: `${progress}%` }} />
          </div>
        </div>

        <Card className="border-border bg-card p-6 md:p-8">
          {step === 0 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-2xl font-bold">Tell us about yourself</h2>
                <p className="text-sm text-muted-foreground">We use this to calculate your protein target.</p>
              </div>
              <div className="space-y-2"><Label>Full name</Label><Input value={form.full_name} onChange={(e) => update("full_name", e.target.value)} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Age</Label><Input type="number" value={form.age} onChange={(e) => update("age", +e.target.value)} /></div>
                <div className="space-y-2">
                  <Label>Sex</Label>
                  <select value={form.sex} onChange={(e) => update("sex", e.target.value)} className="flex h-10 w-full rounded-md border border-input bg-input px-3 text-sm">
                    <option>Male</option><option>Female</option><option>Prefer not to say</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2"><Label>Current weight (kg)</Label><Input type="number" value={form.current_weight} onChange={(e) => update("current_weight", +e.target.value)} /></div>
                <div className="space-y-2"><Label>Target weight (kg)</Label><Input type="number" value={form.target_weight} onChange={(e) => update("target_weight", +e.target.value)} /></div>
                <div className="space-y-2"><Label>Height (cm)</Label><Input type="number" value={form.height} onChange={(e) => update("height", +e.target.value)} /></div>
              </div>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-2xl font-bold">What's your goal?</h2>
                <p className="text-sm text-muted-foreground">Pick one — this drives everything.</p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {GOALS.map((g) => (
                  <button
                    key={g.value}
                    type="button"
                    onClick={() => update("training_goal", g.value)}
                    className={`flex flex-col items-start gap-2 rounded-xl border p-4 text-left transition ${form.training_goal === g.value ? "border-primary bg-primary/10" : "border-border bg-muted/50 hover:bg-muted"}`}
                  >
                    <span className={form.training_goal === g.value ? "text-primary" : "text-muted-foreground"}>{g.icon}</span>
                    <span className="font-semibold">{g.value}</span>
                    <span className="text-xs text-muted-foreground">{g.desc}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold">Workout routine</h2>
                <p className="text-sm text-muted-foreground">When and how do you train?</p>
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Days per week</Label>
                  <span className="text-2xl font-bold text-primary">{form.workout_days}</span>
                </div>
                <Slider value={[form.workout_days]} min={1} max={7} step={1} onValueChange={(v) => update("workout_days", v[0])} />
              </div>
              <div className="space-y-2">
                <Label>Duration</Label>
                <div className="grid grid-cols-4 gap-2">
                  {DURATIONS.map((d) => (
                    <button key={d} type="button" onClick={() => update("workout_duration", d)} className={`rounded-md border py-2 text-sm transition ${form.workout_duration === d ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/50"}`}>{d}</button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Type (multi-select)</Label>
                <div className="flex flex-wrap gap-2">
                  {WORKOUT_TYPES.map((t) => (
                    <button key={t} type="button" onClick={() => toggleArr("workout_types", t)} className={`rounded-full border px-3 py-1.5 text-sm transition ${form.workout_types.includes(t) ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/50"}`}>{t}</button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Time of day</Label>
                <div className="grid grid-cols-4 gap-2">
                  {WORKOUT_TIMES.map((t) => (
                    <button key={t} type="button" onClick={() => update("workout_time", t)} className={`rounded-md border py-2 text-sm transition ${form.workout_time === t ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/50"}`}>{t}</button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-2xl font-bold">Protein preferences</h2>
                <p className="text-sm text-muted-foreground">We'll only suggest these. Pick all that work.</p>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {PROTEIN_PREFS.map((p) => (
                  <button key={p.v} type="button" onClick={() => toggleArr("protein_preferences", p.v)} className={`flex items-center gap-3 rounded-xl border p-4 text-left transition ${form.protein_preferences.includes(p.v) ? "border-primary bg-primary/10" : "border-border bg-muted/50"}`}>
                    <span className="text-2xl">{p.e}</span>
                    <span className="font-medium">{p.v}</span>
                    {form.protein_preferences.includes(p.v) && <Check className="ml-auto h-4 w-4 text-primary" />}
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold">Budget & meals</h2>
                <p className="text-sm text-muted-foreground">All recipes will respect these limits.</p>
              </div>
              <div className="space-y-2">
                <Label>Daily food budget (₹)</Label>
                <div className="grid grid-cols-4 gap-2">
                  {BUDGETS.map((b) => (
                    <button key={b} type="button" onClick={() => update("daily_budget", b)} className={`rounded-md border py-2 text-sm transition ${form.daily_budget === b ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/50"}`}>₹{b}</button>
                  ))}
                </div>
                <Input type="number" value={form.daily_budget} onChange={(e) => update("daily_budget", +e.target.value)} placeholder="Custom amount" />
              </div>
              <div className="space-y-2">
                <Label>Max cook time per meal</Label>
                <div className="grid grid-cols-2 gap-2">
                  {COOK_TIMES.map((c) => (
                    <button key={c} type="button" onClick={() => update("max_cook_time", c)} className={`rounded-md border py-2 text-sm transition ${form.max_cook_time === c ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/50"}`}>{c}</button>
                  ))}
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Meals per day</Label>
                  <span className="text-2xl font-bold text-primary">{form.meals_per_day}</span>
                </div>
                <Slider value={[form.meals_per_day]} min={2} max={6} step={1} onValueChange={(v) => update("meals_per_day", v[0])} />
              </div>
              <div className="space-y-2">
                <Label>Dietary restrictions</Label>
                <div className="flex flex-wrap gap-2">
                  {RESTRICTIONS.map((r) => (
                    <label key={r} className="flex cursor-pointer items-center gap-2 rounded-md border border-border bg-muted/50 px-3 py-2 text-sm">
                      <Checkbox checked={form.dietary_restrictions.includes(r)} onCheckedChange={() => toggleArr("dietary_restrictions", r)} />
                      {r}
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-2xl font-bold">Looks good?</h2>
                <p className="text-sm text-muted-foreground">We'll generate your personalized plan.</p>
              </div>
              <div className="space-y-3 rounded-xl border border-border bg-muted/40 p-4 text-sm">
                <Row label="Name" value={form.full_name} />
                <Row label="Age / Sex" value={`${form.age} · ${form.sex}`} />
                <Row label="Weight" value={`${form.current_weight}kg → ${form.target_weight}kg`} />
                <Row label="Goal" value={form.training_goal} />
                <Row label="Training" value={`${form.workout_days}×/week · ${form.workout_duration} · ${form.workout_time}`} />
                <Row label="Proteins" value={form.protein_preferences.join(", ")} />
                <Row label="Budget" value={`₹${form.daily_budget}/day`} />
                <Row label="Meals/day" value={String(form.meals_per_day)} />
              </div>
              <div className="rounded-xl border border-primary/30 bg-primary/10 p-4">
                <p className="text-xs uppercase tracking-wide text-primary">Your daily protein target</p>
                <p className="mt-1 text-3xl font-bold text-primary">
                  {calcDailyProtein(form.current_weight, form.training_goal)}g
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  ~{Math.round(calcDailyProtein(form.current_weight, form.training_goal) / form.meals_per_day)}g per meal
                </p>
              </div>
            </div>
          )}

          <div className="mt-8 flex items-center justify-between gap-3">
            <Button type="button" variant="ghost" onClick={back} disabled={step === 0} className="text-muted-foreground">
              <ArrowLeft className="mr-2 h-4 w-4" />Back
            </Button>
            {step < total - 1 ? (
              <Button type="button" onClick={next} className="bg-primary text-primary-foreground hover:opacity-90">
                Next<ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            ) : (
              <Button type="button" onClick={submit} disabled={saving} className="bg-primary text-primary-foreground hover:opacity-90">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Generate My Plan"}
              </Button>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}
