import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BottomNav } from "@/components/BottomNav";
import { CoachChat } from "@/components/CoachChat";
import { supabase } from "@/integrations/supabase/client";
import { loadUserContext, type UserContext } from "@/lib/userContext";
import { loadCached, saveCached } from "@/lib/cache";
import { toast } from "sonner";
import { Loader2, Pill, RefreshCw, Leaf, AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/supplements")({ component: SupplementsPage });

type Supp = {
  name: string;
  priority: "Essential" | "Helpful" | "Optional";
  whyForYou: string;
  dosage: string;
  timing: string;
  monthlyCostInr: number;
  naturalAlternatives: string[];
  indianBrands: string[];
  cautions: string;
};
type Data = { supplements: Supp[]; summary: string; totalMonthlyEssentialCost: number };

function SupplementsPage() {
  const navigate = useNavigate();
  const [ctx, setCtx] = useState<UserContext | null>(null);
  const [userId, setUserId] = useState<string>("");
  const [data, setData] = useState<Data | null>(null);
  const [generatedAt, setGeneratedAt] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadUserContext().then(async (r) => {
      if (!r) { navigate({ to: "/auth" }); return; }
      setCtx(r.ctx);
      setUserId(r.userId);
      const cached = await loadCached<Data>(r.userId, "supplements");
      if (cached) { setData(cached.data); setGeneratedAt(cached.generatedAt); }
    });
  }, [navigate]);

  const generate = async () => {
    if (!ctx || !userId) return;
    setLoading(true);
    try {
      const { data: res, error } = await supabase.functions.invoke("supplement-guide", { body: { userContext: ctx } });
      if (error) throw error;
      if (res?.error) throw new Error(res.error);
      setData(res as Data);
      setGeneratedAt(new Date().toISOString());
      await saveCached(userId, "supplements", res);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  };

  const priorityColor = (p: string) =>
    p === "Essential" ? "bg-primary/15 text-primary" : p === "Helpful" ? "bg-warning/15 text-warning" : "bg-muted text-muted-foreground";

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-10 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-4 py-3">
          <div>
            <p className="text-xs text-muted-foreground">Supplement Guide</p>
            <h1 className="text-lg font-bold">Personalized supplements</h1>
          </div>
          <Button onClick={generate} disabled={loading} size="sm" className="bg-primary text-primary-foreground hover:opacity-90">
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            {data ? "Refresh" : "Generate"}
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-4xl space-y-4 px-4 pt-5">
        <div className="flex items-start gap-2 rounded-xl border border-warning/30 bg-warning/5 p-3 text-xs">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
          <p>FitProtein Coach provides general nutrition guidance only. Consult a certified dietitian or doctor for medical advice.</p>
        </div>

        {!data && !loading && (
          <Card className="border-dashed border-border bg-card/50 p-10 text-center">
            <Pill className="mx-auto mb-3 h-8 w-8 text-primary" />
            <p className="font-medium">Get your supplement plan</p>
            <p className="mt-1 text-sm text-muted-foreground">Gemini will recommend supplements based on your goals & diet.</p>
          </Card>
        )}
        {loading && (
          <Card className="border-border bg-card p-10 text-center">
            <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary" />
          </Card>
        )}

        {data && generatedAt && (
          <p className="text-center text-xs text-muted-foreground">Saved · generated {new Date(generatedAt).toLocaleString()}</p>
        )}

        {data?.summary && (
          <div className="rounded-xl border border-primary/30 bg-primary/5 p-4 text-sm">{data.summary}</div>
        )}

        {data?.supplements?.map((s, i) => (
          <Card key={i} className="border-border bg-card p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-lg font-semibold">{s.name}</h3>
                <span className={`mt-1 inline-block rounded-full px-2 py-0.5 text-xs font-medium ${priorityColor(s.priority)}`}>{s.priority}</span>
              </div>
              <div className="text-right text-xs text-muted-foreground">
                <p className="font-bold text-foreground">₹{s.monthlyCostInr}/mo</p>
              </div>
            </div>
            <p className="mt-2 text-sm">{s.whyForYou}</p>
            <div className="mt-3 grid grid-cols-1 gap-2 text-xs sm:grid-cols-2">
              <div><strong className="text-muted-foreground">Dosage:</strong> {s.dosage}</div>
              <div><strong className="text-muted-foreground">Timing:</strong> {s.timing}</div>
            </div>
            {s.naturalAlternatives?.length > 0 && (
              <div className="mt-3 rounded-md bg-muted/50 p-3 text-xs">
                <p className="mb-1 flex items-center gap-1 font-medium text-primary"><Leaf className="h-3 w-3" /> Natural alternatives</p>
                <p className="text-muted-foreground">{s.naturalAlternatives.join(" · ")}</p>
              </div>
            )}
            {s.indianBrands?.length > 0 && (
              <p className="mt-2 text-xs text-muted-foreground"><strong>Brands:</strong> {s.indianBrands.join(", ")}</p>
            )}
            {s.cautions && (
              <p className="mt-2 text-xs italic text-warning">⚠ {s.cautions}</p>
            )}
          </Card>
        ))}

        {data && (
          <p className="pt-2 text-center text-sm">
            <span className="text-muted-foreground">Essential monthly cost: </span>
            <span className="font-bold text-primary">₹{data.totalMonthlyEssentialCost}</span>
          </p>
        )}
        <p className="pt-2 text-center text-xs text-muted-foreground">AI Powered by Gemini</p>
      </main>
      <CoachChat />
      <BottomNav />
    </div>
  );
}
