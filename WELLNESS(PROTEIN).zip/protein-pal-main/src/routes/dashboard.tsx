import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Loader2, RefreshCw, LogOut, Flame, Clock, IndianRupee, Sparkles, Check, User, Trophy } from "lucide-react";
import { ProteinRing } from "@/components/ProteinRing";
import { BottomNav } from "@/components/BottomNav";
import { CoachChat } from "@/components/CoachChat";
import { computeStreak } from "@/lib/cache";

export const Route = createFileRoute("/dashboard")({
  component: Dashboard,
});

type Profile = {
  id: string;
  full_name: string | null;
  daily_protein_target: number | null;
  daily_budget: number | null;
  max_cook_time: string | null;
  meals_per_day: number | null;
  protein_preferences: string[] | null;
  dietary_restrictions: string[] | null;
  training_goal: string | null;
  workout_time: string | null;
  current_weight: number | null;
};

type Meal = {
  mealType: string;
  time: string;
  recipeName: string;
  proteinSources: string[];
  totalProtein: number;
  totalCalories: number;
  estimatedCost: number;
  cookTime: number;
  ingredients: { item: string; quantity: string; proteinContribution: number }[];
  steps: string[];
  proTip: string;
  goalReason: string;
};

type Plan = {
  mealPlan: Meal[];
  totalDayProtein: number;
  totalDayCost: number;
  totalDayCalories: number;
  aiNote: string;
};

function Dashboard() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [plan, setPlan] = useState<Plan | null>(null);
  const [generating, setGenerating] = useState(false);
  const [todayProtein, setTodayProtein] = useState(0);
  const [eatenMeals, setEatenMeals] = useState<Set<string>>(new Set());
  const [streak, setStreak] = useState(0);

  const today = new Date().toISOString().slice(0, 10);

  const loadAll = useCallback(async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) { navigate({ to: "/auth" }); return; }

    const since = new Date(Date.now() - 60 * 86400000).toISOString().slice(0, 10);
    const [{ data: prof }, { data: planRow }, { data: logs }, { data: history }] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", session.user.id).maybeSingle(),
      supabase.from("daily_plans").select("plan_data").eq("user_id", session.user.id).eq("plan_date", today).maybeSingle(),
      supabase.from("meal_logs").select("meal_name,protein_grams").eq("user_id", session.user.id).eq("log_date", today),
      supabase.from("meal_logs").select("log_date,protein_grams").eq("user_id", session.user.id).gte("log_date", since),
    ]);

    if (!prof?.onboarding_completed) { navigate({ to: "/onboarding" }); return; }
    setProfile(prof as Profile);
    if (planRow?.plan_data) setPlan(planRow.plan_data as Plan);
    if (logs) {
      setEatenMeals(new Set(logs.map((l) => l.meal_name)));
      setTodayProtein(logs.reduce((s, l) => s + Number(l.protein_grams || 0), 0));
    }
    if (history && prof?.daily_protein_target) {
      const totals = history.reduce<Record<string, number>>((acc, h) => {
        acc[h.log_date] = (acc[h.log_date] || 0) + Number(h.protein_grams || 0);
        return acc;
      }, {});
      setStreak(computeStreak(totals, Number(prof.daily_protein_target)));
    }
  }, [navigate, today]);

  useEffect(() => { loadAll(); }, [loadAll]);

  const generatePlan = async () => {
    if (!profile) return;
    setGenerating(true);
    try {
      const userContext = {
        name: profile.full_name,
        currentWeight: profile.current_weight,
        trainingGoal: profile.training_goal,
        workoutTime: profile.workout_time,
        proteinPreferences: profile.protein_preferences,
        dietaryRestrictions: profile.dietary_restrictions,
        dailyBudget: profile.daily_budget,
        maxCookTime: profile.max_cook_time,
        mealsPerDay: profile.meals_per_day,
        dailyProteinTarget: profile.daily_protein_target,
        todayProteinConsumed: todayProtein,
      };
      const { data, error } = await supabase.functions.invoke("generate-meal-plan", { body: { userContext } });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      const newPlan = data as Plan;
      setPlan(newPlan);
      await supabase.from("daily_plans").upsert({
        user_id: profile.id,
        plan_date: today,
        plan_data: newPlan,
      }, { onConflict: "user_id,plan_date" });
      toast.success("Fresh plan generated!");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Generation failed");
    } finally {
      setGenerating(false);
    }
  };

  const markEaten = async (meal: Meal) => {
    if (!profile || eatenMeals.has(meal.recipeName)) return;
    const { error } = await supabase.from("meal_logs").insert({
      user_id: profile.id,
      log_date: today,
      meal_name: meal.recipeName,
      protein_grams: meal.totalProtein,
      calories: meal.totalCalories,
      cost: meal.estimatedCost,
    });
    if (error) { toast.error("Failed to log"); return; }
    const newTotal = todayProtein + meal.totalProtein;
    const target = profile.daily_protein_target || 0;
    const wasUnder = todayProtein < target;
    const nowHit = newTotal >= target && target > 0;
    setEatenMeals((s) => new Set(s).add(meal.recipeName));
    setTodayProtein(newTotal);
    if (wasUnder && nowHit) {
      const newStreak = streak + 1;
      setStreak(newStreak);
      toast.success(`🔥 Goal hit! ${newStreak}-day streak!`);
    } else {
      toast.success(`Logged ${meal.totalProtein}g protein`);
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  };

  if (!profile) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  const target = profile.daily_protein_target || 0;
  const pct = target > 0 ? Math.min(100, (todayProtein / target) * 100) : 0;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <header className="sticky top-0 z-10 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-4 py-3">
          <div>
            <p className="text-xs text-muted-foreground">FitProtein Coach</p>
            <h1 className="text-lg font-bold">Hi, {profile.full_name?.split(" ")[0] || "there"} 👋</h1>
          </div>
          <div className="flex items-center gap-1">
            {streak > 0 && (
              <span className="mr-1 inline-flex items-center gap-1 rounded-full border border-warning/40 bg-warning/10 px-2.5 py-1 text-xs font-bold text-warning" aria-label={`${streak}-day streak`}>
                <Trophy className="h-3.5 w-3.5" />{streak}🔥
              </span>
            )}
            <Link to="/profile" className="inline-flex h-9 w-9 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground" aria-label="Profile">
              <User className="h-4 w-4" />
            </Link>
            <Button variant="ghost" size="sm" onClick={signOut} className="text-muted-foreground" aria-label="Sign out">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl space-y-6 px-4 pt-6">
        {/* Progress ring */}
        <Card className="border-border bg-card p-6">
          <div className="flex flex-col items-center gap-4 md:flex-row md:gap-8">
            <ProteinRing value={todayProtein} target={target} />
            <div className="flex-1 space-y-2 text-center md:text-left">
              <p className="text-sm text-muted-foreground">Today's protein</p>
              <p className="text-3xl font-bold">
                <span className={pct >= 90 ? "text-primary" : pct >= 60 ? "text-warning" : "text-accent"}>{todayProtein}g</span>
                <span className="text-muted-foreground"> / {target}g</span>
              </p>
              <p className="text-sm text-muted-foreground">
                {pct >= 100 ? `🎯 Target hit! ${streak > 0 ? `${streak}-day streak 🔥` : "Excellent."}` : `${Math.round(target - todayProtein)}g to go${streak > 0 ? ` · keep your ${streak}-day streak alive 🔥` : ""}`}
              </p>
              <div className="flex flex-wrap justify-center gap-2 pt-2 md:justify-start">
                <Button onClick={generatePlan} disabled={generating} size="sm" className="bg-primary text-primary-foreground hover:opacity-90">
                  {generating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
                  {plan ? "Regenerate plan" : "Generate today's plan"}
                </Button>
              </div>
            </div>
          </div>
        </Card>

        {/* AI insight banner */}
        {plan?.aiNote && (
          <div className="flex items-start gap-3 rounded-xl border border-primary/30 bg-primary/5 p-4">
            <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
            <p className="text-sm">{plan.aiNote}</p>
          </div>
        )}

        {/* Meal plan */}
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">Today's AI meal plan</h2>
            {plan && (
              <p className="text-xs text-muted-foreground">
                {plan.totalDayProtein}g · {plan.totalDayCalories} kcal · ₹{plan.totalDayCost}
              </p>
            )}
          </div>

          {!plan && !generating && (
            <Card className="border-dashed border-border bg-card/50 p-10 text-center">
              <Sparkles className="mx-auto mb-3 h-8 w-8 text-primary" />
              <p className="font-medium">No plan for today yet</p>
              <p className="mt-1 text-sm text-muted-foreground">Tap "Generate today's plan" to get a personalized Indian meal plan from Gemini.</p>
            </Card>
          )}

          {generating && (
            <Card className="border-border bg-card p-10 text-center">
              <Loader2 className="mx-auto mb-3 h-8 w-8 animate-spin text-primary" />
              <p className="font-medium">Cooking up your plan…</p>
              <p className="mt-1 text-sm text-muted-foreground">Gemini is personalizing meals for your goal & budget.</p>
            </Card>
          )}

          {plan?.mealPlan?.map((m, i) => {
            const eaten = eatenMeals.has(m.recipeName);
            return (
              <Card key={i} className={`border-border bg-card p-5 transition ${eaten ? "opacity-70" : ""}`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                      <span className="rounded-full bg-primary/15 px-2 py-0.5 font-medium text-primary">{m.mealType}</span>
                      <span>{m.time}</span>
                    </div>
                    <h3 className="mt-1 text-lg font-semibold">{m.recipeName}</h3>
                    <div className="mt-2 flex flex-wrap gap-3 text-xs text-muted-foreground">
                      <span className="inline-flex items-center gap-1"><Flame className="h-3.5 w-3.5 text-primary" />{m.totalProtein}g protein</span>
                      <span className="inline-flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{m.cookTime} min</span>
                      <span className="inline-flex items-center gap-1"><IndianRupee className="h-3.5 w-3.5" />{m.estimatedCost}</span>
                      <span>{m.totalCalories} kcal</span>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => markEaten(m)}
                    disabled={eaten}
                    className={eaten ? "bg-primary/30 text-primary" : "bg-primary text-primary-foreground hover:opacity-90"}
                  >
                    {eaten ? <><Check className="mr-1 h-4 w-4" />Eaten</> : "Mark eaten"}
                  </Button>
                </div>

                <details className="group mt-4">
                  <summary className="cursor-pointer text-sm font-medium text-primary">Recipe & ingredients</summary>
                  <div className="mt-3 space-y-3 text-sm">
                    <div>
                      <p className="mb-1 font-medium text-muted-foreground">Ingredients</p>
                      <ul className="space-y-1">
                        {m.ingredients?.map((ing, j) => (
                          <li key={j} className="flex justify-between gap-3 text-muted-foreground">
                            <span>{ing.item}</span><span>{ing.quantity}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <p className="mb-1 font-medium text-muted-foreground">Steps</p>
                      <ol className="list-decimal space-y-1 pl-5 text-muted-foreground">
                        {m.steps?.map((s, j) => <li key={j}>{s}</li>)}
                      </ol>
                    </div>
                    {m.proTip && <p className="rounded-md bg-muted/50 p-3 text-xs"><strong className="text-primary">Pro tip:</strong> {m.proTip}</p>}
                    {m.goalReason && <p className="text-xs text-muted-foreground italic">Why this meal: {m.goalReason}</p>}
                  </div>
                </details>
              </Card>
            );
          })}
        </section>

        <p className="pt-6 text-center text-xs text-muted-foreground">AI Powered by Gemini</p>
      </main>
      <CoachChat />
      <BottomNav />
    </div>
  );
}
