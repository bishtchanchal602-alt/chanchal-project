import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { BottomNav } from "@/components/BottomNav";
import { CoachChat } from "@/components/CoachChat";
import { supabase } from "@/integrations/supabase/client";
import { loadUserContext, type UserContext } from "@/lib/userContext";
import { toast } from "sonner";
import { Loader2, Search, Sparkles, Flame, Clock, IndianRupee, ChefHat, History, X } from "lucide-react";

export const Route = createFileRoute("/recipes")({ component: RecipesPage });

type Recipe = {
  name: string;
  tagline: string;
  totalProtein: number;
  totalCalories: number;
  estimatedCost: number;
  cookTime: number;
  difficulty: string;
  ingredients: { item: string; quantity: string; proteinContribution: number }[];
  steps: string[];
  proTip: string;
  whyThis: string;
};

const SUGGESTIONS = ["High-protein breakfast under 10 min", "Vegetarian post-workout meal", "Paneer dinner under ₹100", "Egg-based snacks", "Soya chunks recipes"];

function RecipesPage() {
  const navigate = useNavigate();
  const [ctx, setCtx] = useState<UserContext | null>(null);
  const [userId, setUserId] = useState<string>("");
  const [query, setQuery] = useState("");
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [lastQuery, setLastQuery] = useState<string>("");
  const [history, setHistory] = useState<{ id: string; query: string }[]>([]);
  const [loading, setLoading] = useState(false);

  const loadHistory = async (uid: string) => {
    const { data } = await supabase
      .from("recipe_searches")
      .select("id,query")
      .eq("user_id", uid)
      .order("created_at", { ascending: false })
      .limit(8);
    setHistory((data as { id: string; query: string }[]) || []);
  };

  useEffect(() => {
    loadUserContext().then(async (r) => {
      if (!r) { navigate({ to: "/auth" }); return; }
      setCtx(r.ctx);
      setUserId(r.userId);
      await loadHistory(r.userId);
    });
  }, [navigate]);

  const search = async (q: string) => {
    if (!q.trim() || !ctx || !userId) return;
    setLoading(true);
    setRecipes([]);
    try {
      const { data, error } = await supabase.functions.invoke("recipe-search", { body: { query: q, userContext: ctx } });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setRecipes(data.recipes || []);
      setLastQuery(q);
      // dedupe: remove same query if exists, then insert
      await supabase.from("recipe_searches").delete().eq("user_id", userId).eq("query", q);
      await supabase.from("recipe_searches").insert({ user_id: userId, query: q });
      await loadHistory(userId);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Search failed");
    } finally {
      setLoading(false);
    }
  };

  const removeHistoryItem = async (id: string) => {
    await supabase.from("recipe_searches").delete().eq("id", id);
    setHistory((h) => h.filter((x) => x.id !== id));
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-10 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto max-w-4xl px-4 py-3">
          <p className="text-xs text-muted-foreground">AI Recipe Search</p>
          <h1 className="text-lg font-bold">Find your next high-protein meal</h1>
        </div>
      </header>

      <main className="mx-auto max-w-4xl space-y-4 px-4 pt-5">
        <form onSubmit={(e) => { e.preventDefault(); search(query); }} className="flex gap-2">
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="e.g. quick paneer dinner" className="bg-card" />
          <Button type="submit" disabled={loading} className="bg-primary text-primary-foreground hover:opacity-90">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          </Button>
        </form>

        {history.length > 0 && (
          <div className="space-y-2">
            <p className="flex items-center gap-1.5 text-xs text-muted-foreground"><History className="h-3.5 w-3.5" />Recent searches</p>
            <div className="flex flex-wrap gap-2">
              {history.map((h) => (
                <span key={h.id} className="group inline-flex items-center gap-1 rounded-full border border-border bg-card pl-3 pr-1 py-1 text-xs">
                  <button onClick={() => { setQuery(h.query); search(h.query); }} className="text-foreground transition hover:text-primary">{h.query}</button>
                  <button onClick={() => removeHistoryItem(h.id)} aria-label="Remove" className="rounded-full p-0.5 text-muted-foreground hover:bg-muted hover:text-foreground"><X className="h-3 w-3" /></button>
                </span>
              ))}
            </div>
          </div>
        )}

        {!recipes.length && !loading && (
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground">Try these:</p>
            <div className="flex flex-wrap gap-2">
              {SUGGESTIONS.map((s) => (
                <button key={s} onClick={() => { setQuery(s); search(s); }} className="rounded-full border border-border bg-card px-3 py-1.5 text-xs text-muted-foreground transition hover:border-primary hover:text-primary">
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {recipes.length > 0 && lastQuery && (
          <p className="text-xs text-muted-foreground">Showing results for: <span className="text-foreground">"{lastQuery}"</span></p>
        )}

        {loading && (
          <Card className="border-border bg-card p-10 text-center">
            <Loader2 className="mx-auto mb-3 h-8 w-8 animate-spin text-primary" />
            <p className="text-sm">Gemini is finding recipes for you…</p>
          </Card>
        )}

        {recipes.map((r, i) => (
          <Card key={i} className="border-border bg-card p-5">
            <div className="flex items-start gap-2">
              <ChefHat className="mt-1 h-5 w-5 shrink-0 text-primary" />
              <div className="flex-1">
                <h3 className="text-lg font-semibold">{r.name}</h3>
                <p className="text-xs text-muted-foreground">{r.tagline}</p>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-3 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1"><Flame className="h-3.5 w-3.5 text-primary" />{r.totalProtein}g</span>
              <span className="inline-flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{r.cookTime} min</span>
              <span className="inline-flex items-center gap-1"><IndianRupee className="h-3.5 w-3.5" />{r.estimatedCost}</span>
              <span>{r.totalCalories} kcal</span>
              <span className="rounded-full bg-muted px-2">{r.difficulty}</span>
            </div>
            <details className="group mt-4">
              <summary className="cursor-pointer text-sm font-medium text-primary">Recipe & ingredients</summary>
              <div className="mt-3 space-y-3 text-sm">
                <div>
                  <p className="mb-1 font-medium text-muted-foreground">Ingredients</p>
                  <ul className="space-y-1">
                    {r.ingredients?.map((ing, j) => (
                      <li key={j} className="flex justify-between gap-3 text-muted-foreground">
                        <span>{ing.item}</span><span>{ing.quantity}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <p className="mb-1 font-medium text-muted-foreground">Steps</p>
                  <ol className="list-decimal space-y-1 pl-5 text-muted-foreground">
                    {r.steps?.map((s, j) => <li key={j}>{s}</li>)}
                  </ol>
                </div>
                {r.proTip && <p className="rounded-md bg-muted/50 p-3 text-xs"><Sparkles className="mr-1 inline h-3 w-3 text-primary" /><strong className="text-primary">Pro tip:</strong> {r.proTip}</p>}
                {r.whyThis && <p className="text-xs italic text-muted-foreground">Why this fits you: {r.whyThis}</p>}
              </div>
            </details>
          </Card>
        ))}
        <p className="pt-4 text-center text-xs text-muted-foreground">AI Powered by Gemini</p>
      </main>
      <CoachChat />
      <BottomNav />
    </div>
  );
}
