import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BottomNav } from "@/components/BottomNav";
import { CoachChat } from "@/components/CoachChat";
import { supabase } from "@/integrations/supabase/client";
import { loadUserContext, type UserContext } from "@/lib/userContext";
import { loadCached, saveCached } from "@/lib/cache";
import { toast } from "sonner";
import { Loader2, CalendarDays, RefreshCw, ShoppingCart } from "lucide-react";

export const Route = createFileRoute("/weekly")({ component: WeeklyPage });

type Meal = { mealType: string; recipeName: string; totalProtein: number; totalCalories: number; estimatedCost: number };
type Day = { day: string; meals: Meal[]; dayProtein: number; dayCost: number };
type Grocery = { item: string; quantity: string; estimatedCost: number; category: string };
type Data = { days: Day[]; groceryList: Grocery[]; totalWeekCost: number; aiNote: string };

function WeeklyPage() {
  const navigate = useNavigate();
  const [ctx, setCtx] = useState<UserContext | null>(null);
  const [userId, setUserId] = useState<string>("");
  const [data, setData] = useState<Data | null>(null);
  const [generatedAt, setGeneratedAt] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<"plan" | "grocery">("plan");

  useEffect(() => {
    loadUserContext().then(async (r) => {
      if (!r) { navigate({ to: "/auth" }); return; }
      setCtx(r.ctx);
      setUserId(r.userId);
      const cached = await loadCached<Data>(r.userId, "weekly");
      if (cached) { setData(cached.data); setGeneratedAt(cached.generatedAt); }
    });
  }, [navigate]);

  const generate = async () => {
    if (!ctx || !userId) return;
    setLoading(true);
    try {
      const { data: res, error } = await supabase.functions.invoke("weekly-plan", { body: { userContext: ctx } });
      if (error) throw error;
      if (res?.error) throw new Error(res.error);
      setData(res as Data);
      setGeneratedAt(new Date().toISOString());
      await saveCached(userId, "weekly", res);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  };

  const grouped = (data?.groceryList || []).reduce<Record<string, Grocery[]>>((acc, g) => {
    (acc[g.category] = acc[g.category] || []).push(g);
    return acc;
  }, {});

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-10 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-4 py-3">
          <div>
            <p className="text-xs text-muted-foreground">Weekly plan</p>
            <h1 className="text-lg font-bold">7-day meal plan</h1>
          </div>
          <Button onClick={generate} disabled={loading} size="sm" className="bg-primary text-primary-foreground hover:opacity-90">
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            {data ? "Refresh" : "Generate"}
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-4xl space-y-4 px-4 pt-5">
        {!data && !loading && (
          <Card className="border-dashed border-border bg-card/50 p-10 text-center">
            <CalendarDays className="mx-auto mb-3 h-8 w-8 text-primary" />
            <p className="font-medium">Plan your whole week</p>
            <p className="mt-1 text-sm text-muted-foreground">Get 7 days of meals + a smart grocery list.</p>
          </Card>
        )}
        {loading && (
          <Card className="border-border bg-card p-10 text-center">
            <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary" />
            <p className="mt-3 text-sm">Building your week with Gemini…</p>
          </Card>
        )}

        {data && (
          <>
            {generatedAt && <p className="text-center text-xs text-muted-foreground">Saved · generated {new Date(generatedAt).toLocaleString()}</p>}
            {data.aiNote && <div className="rounded-xl border border-primary/30 bg-primary/5 p-4 text-sm">{data.aiNote}</div>}
            <div className="flex gap-2 rounded-lg bg-card p-1">
              <button onClick={() => setTab("plan")} className={`flex-1 rounded-md px-3 py-1.5 text-sm font-medium transition ${tab === "plan" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>Plan</button>
              <button onClick={() => setTab("grocery")} className={`flex-1 rounded-md px-3 py-1.5 text-sm font-medium transition ${tab === "grocery" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
                Grocery (₹{data.totalWeekCost})
              </button>
            </div>

            {tab === "plan" && data.days?.map((d, i) => (
              <Card key={i} className="border-border bg-card p-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold">{d.day}</h3>
                  <p className="text-xs text-muted-foreground">{d.dayProtein}g · ₹{d.dayCost}</p>
                </div>
                <div className="mt-3 space-y-2">
                  {d.meals?.map((m, j) => (
                    <div key={j} className="flex justify-between gap-3 border-t border-border pt-2 text-sm first:border-t-0 first:pt-0">
                      <div>
                        <p className="text-xs uppercase tracking-wide text-primary">{m.mealType}</p>
                        <p>{m.recipeName}</p>
                      </div>
                      <div className="text-right text-xs text-muted-foreground">
                        <p className="font-bold text-foreground">{m.totalProtein}g</p>
                        <p>₹{m.estimatedCost}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            ))}

            {tab === "grocery" && (
              <div className="space-y-3">
                {Object.entries(grouped).map(([cat, items]) => (
                  <Card key={cat} className="border-border bg-card p-4">
                    <h3 className="mb-2 flex items-center gap-2 font-bold"><ShoppingCart className="h-4 w-4 text-primary" />{cat}</h3>
                    <ul className="space-y-1 text-sm">
                      {items.map((g, i) => (
                        <li key={i} className="flex justify-between gap-3 text-muted-foreground">
                          <span>{g.item} <span className="text-xs">({g.quantity})</span></span>
                          <span>₹{g.estimatedCost}</span>
                        </li>
                      ))}
                    </ul>
                  </Card>
                ))}
              </div>
            )}
          </>
        )}
        <p className="pt-4 text-center text-xs text-muted-foreground">AI Powered by Gemini</p>
      </main>
      <CoachChat />
      <BottomNav />
    </div>
  );
}
