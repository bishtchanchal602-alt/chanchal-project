import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BottomNav } from "@/components/BottomNav";
import { CoachChat } from "@/components/CoachChat";
import { supabase } from "@/integrations/supabase/client";
import { loadUserContext, type UserContext } from "@/lib/userContext";
import { loadCached, saveCached } from "@/lib/cache";
import { toast } from "sonner";
import { Loader2, Dumbbell, Zap, RefreshCw, Droplet } from "lucide-react";

export const Route = createFileRoute("/workout")({ component: WorkoutPage });

type Snack = { name: string; timing: string; protein: number; calories: number; cost: number; prepTime: number; ingredients: string[]; why: string };
type Data = { pre: Snack[]; post: Snack[]; hydrationTip: string; aiNote: string };

function WorkoutPage() {
  const navigate = useNavigate();
  const [ctx, setCtx] = useState<UserContext | null>(null);
  const [userId, setUserId] = useState<string>("");
  const [data, setData] = useState<Data | null>(null);
  const [generatedAt, setGeneratedAt] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadUserContext().then(async (r) => {
      if (!r) { navigate({ to: "/auth" }); return; }
      setCtx(r.ctx);
      setUserId(r.userId);
      const cached = await loadCached<Data>(r.userId, "workout");
      if (cached) { setData(cached.data); setGeneratedAt(cached.generatedAt); }
    });
  }, [navigate]);

  const generate = async () => {
    if (!ctx || !userId) return;
    setLoading(true);
    try {
      const { data: res, error } = await supabase.functions.invoke("workout-nutrition", { body: { userContext: ctx } });
      if (error) throw error;
      if (res?.error) throw new Error(res.error);
      setData(res as Data);
      setGeneratedAt(new Date().toISOString());
      await saveCached(userId, "workout", res);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  };

  const Section = ({ title, items, icon: Icon, color }: { title: string; items: Snack[]; icon: typeof Zap; color: string }) => (
    <section className="space-y-3">
      <h2 className="flex items-center gap-2 text-lg font-bold">
        <Icon className={`h-5 w-5 ${color}`} />{title}
      </h2>
      {items.map((s, i) => (
        <Card key={i} className="border-border bg-card p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="font-semibold">{s.name}</h3>
              <p className="text-xs text-muted-foreground">{s.timing}</p>
            </div>
            <div className="text-right text-xs">
              <p className="font-bold text-primary">{s.protein}g protein</p>
              <p className="text-muted-foreground">{s.calories} kcal · ₹{s.cost}</p>
            </div>
          </div>
          <p className="mt-2 text-xs text-muted-foreground"><strong>Ingredients:</strong> {s.ingredients?.join(", ")}</p>
          <p className="mt-1 text-xs italic text-muted-foreground">{s.why}</p>
        </Card>
      ))}
    </section>
  );

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-10 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-4 py-3">
          <div>
            <p className="text-xs text-muted-foreground">Pre / Post Workout</p>
            <h1 className="text-lg font-bold">Fuel your training</h1>
          </div>
          <Button onClick={generate} disabled={loading} size="sm" className="bg-primary text-primary-foreground hover:opacity-90">
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            {data ? "Refresh" : "Generate"}
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-4xl space-y-6 px-4 pt-5">
        {!data && !loading && (
          <Card className="border-dashed border-border bg-card/50 p-10 text-center">
            <Dumbbell className="mx-auto mb-3 h-8 w-8 text-primary" />
            <p className="font-medium">Get your workout fuel plan</p>
            <p className="mt-1 text-sm text-muted-foreground">Personalized pre & post-workout snacks from Gemini.</p>
          </Card>
        )}
        {loading && (
          <Card className="border-border bg-card p-10 text-center">
            <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary" />
          </Card>
        )}
        {data && (
          <>
            {generatedAt && (
              <p className="text-center text-xs text-muted-foreground">Saved · generated {new Date(generatedAt).toLocaleString()}</p>
            )}
            {data.aiNote && (
              <div className="rounded-xl border border-primary/30 bg-primary/5 p-4 text-sm">{data.aiNote}</div>
            )}
            <Section title="Pre-workout" items={data.pre || []} icon={Zap} color="text-warning" />
            <Section title="Post-workout" items={data.post || []} icon={Dumbbell} color="text-primary" />
            {data.hydrationTip && (
              <Card className="border-border bg-card p-4">
                <p className="flex items-start gap-2 text-sm"><Droplet className="mt-0.5 h-4 w-4 shrink-0 text-accent" />{data.hydrationTip}</p>
              </Card>
            )}
          </>
        )}
        <p className="pt-4 text-center text-xs text-muted-foreground">AI Powered by Gemini</p>
      </main>
      <CoachChat />
      <BottomNav />
    </div>
  );
}
