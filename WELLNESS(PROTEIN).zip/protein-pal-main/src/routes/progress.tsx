import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { BottomNav } from "@/components/BottomNav";
import { CoachChat } from "@/components/CoachChat";
import { supabase } from "@/integrations/supabase/client";
import { loadUserContext, type UserContext } from "@/lib/userContext";
import { loadCached, saveCached } from "@/lib/cache";
import { toast } from "sonner";
import { Loader2, TrendingUp, Plus, Sparkles, CheckCircle2, AlertCircle, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/progress")({ component: ProgressPage });

type WLog = { log_date: string; weight: number };
type MLog = { log_date: string; protein_grams: number };
type Insights = {
  headline: string; adherencePct: number; weightTrend: string; weightChangeKg: number;
  wins: string[]; warnings: string[]; nextActions: string[];
};
type Period = "daily" | "weekly";

function ProgressPage() {
  const navigate = useNavigate();
  const [ctx, setCtx] = useState<UserContext | null>(null);
  const [userId, setUserId] = useState<string>("");
  const [weights, setWeights] = useState<WLog[]>([]);
  const [meals, setMeals] = useState<MLog[]>([]);
  const [newWeight, setNewWeight] = useState("");
  const [period, setPeriod] = useState<Period>("daily");
  const [insightsDaily, setInsightsDaily] = useState<Insights | null>(null);
  const [insightsWeekly, setInsightsWeekly] = useState<Insights | null>(null);
  const [insightsAtDaily, setInsightsAtDaily] = useState<string | null>(null);
  const [insightsAtWeekly, setInsightsAtWeekly] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const reload = useCallback(async (uid: string) => {
    const since = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);
    const [{ data: w }, { data: m }] = await Promise.all([
      supabase.from("weight_logs").select("log_date,weight").eq("user_id", uid).gte("log_date", since).order("log_date", { ascending: false }),
      supabase.from("meal_logs").select("log_date,protein_grams").eq("user_id", uid).gte("log_date", since).order("log_date", { ascending: false }),
    ]);
    setWeights((w as WLog[]) || []);
    setMeals((m as MLog[]) || []);
  }, []);

  useEffect(() => {
    loadUserContext().then(async (r) => {
      if (!r) { navigate({ to: "/auth" }); return; }
      setCtx(r.ctx);
      setUserId(r.userId);
      await reload(r.userId);
      const [d, wk] = await Promise.all([
        loadCached<Insights>(r.userId, "progress_daily"),
        loadCached<Insights>(r.userId, "progress_weekly"),
      ]);
      if (d) { setInsightsDaily(d.data); setInsightsAtDaily(d.generatedAt); }
      if (wk) { setInsightsWeekly(wk.data); setInsightsAtWeekly(wk.generatedAt); }
    });
  }, [navigate, reload]);

  const logWeight = async () => {
    const w = parseFloat(newWeight);
    if (!w || !userId) return;
    const today = new Date().toISOString().slice(0, 10);
    const { error } = await supabase.from("weight_logs").upsert({ user_id: userId, log_date: today, weight: w });
    if (error) { toast.error("Failed"); return; }
    await supabase.from("profiles").update({ current_weight: w }).eq("id", userId);
    toast.success("Weight logged");
    setNewWeight("");
    await reload(userId);
  };

  const generateInsights = async () => {
    if (!ctx || !userId) return;
    setLoading(true);
    try {
      const days = period === "daily" ? 7 : 30;
      const dailyProtein = meals.reduce<Record<string, number>>((acc, m) => {
        acc[m.log_date] = (acc[m.log_date] || 0) + Number(m.protein_grams);
        return acc;
      }, {});
      const { data, error } = await supabase.functions.invoke("progress-insights", {
        body: {
          userContext: ctx,
          period,
          weightLogs: weights.slice(0, days),
          mealLogs: Object.entries(dailyProtein).map(([date, total]) => ({ date, total })).slice(0, days),
        },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      const ins = data as Insights;
      const now = new Date().toISOString();
      if (period === "daily") {
        setInsightsDaily(ins); setInsightsAtDaily(now);
        await saveCached(userId, "progress_daily", ins);
      } else {
        setInsightsWeekly(ins); setInsightsAtWeekly(now);
        await saveCached(userId, "progress_weekly", ins);
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  };

  // simple weight chart (sparkline)
  const sortedWeights = [...weights].reverse();
  const minW = Math.min(...sortedWeights.map(w => w.weight), Infinity);
  const maxW = Math.max(...sortedWeights.map(w => w.weight), -Infinity);
  const range = maxW - minW || 1;

  // protein adherence
  const target = ctx?.dailyProteinTarget || 100;
  const barCount = period === "daily" ? 7 : 30;
  const bars = Array.from({ length: barCount }, (_, i) => {
    const d = new Date(Date.now() - (barCount - 1 - i) * 86400000).toISOString().slice(0, 10);
    const total = meals.filter(m => m.log_date === d).reduce((s, m) => s + Number(m.protein_grams), 0);
    return { date: d, total, pct: Math.min(100, (total / target) * 100) };
  });

  const insights = period === "daily" ? insightsDaily : insightsWeekly;
  const insightsAt = period === "daily" ? insightsAtDaily : insightsAtWeekly;

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-10 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto max-w-4xl px-4 py-3">
          <p className="text-xs text-muted-foreground">Progress</p>
          <h1 className="text-lg font-bold">Your trend</h1>
        </div>
      </header>

      <main className="mx-auto max-w-4xl space-y-4 px-4 pt-5">
        {/* Log weight */}
        <Card className="border-border bg-card p-4">
          <p className="text-sm font-medium">Log today's weight</p>
          <div className="mt-2 flex gap-2">
            <Input type="number" step="0.1" placeholder={`${ctx?.currentWeight || ""} kg`} value={newWeight} onChange={(e) => setNewWeight(e.target.value)} className="bg-background" />
            <Button onClick={logWeight} className="bg-primary text-primary-foreground hover:opacity-90"><Plus className="h-4 w-4" /></Button>
          </div>
        </Card>

        {/* Weight chart */}
        <Card className="border-border bg-card p-4">
          <h3 className="flex items-center gap-2 font-bold"><TrendingUp className="h-4 w-4 text-primary" />Weight (last {sortedWeights.length} entries)</h3>
          {sortedWeights.length < 2 ? (
            <p className="mt-3 text-sm text-muted-foreground">Log at least 2 weights to see your trend.</p>
          ) : (
            <>
              <svg viewBox="0 0 300 80" className="mt-3 h-24 w-full overflow-visible">
                <polyline
                  fill="none" stroke="var(--primary)" strokeWidth="2"
                  points={sortedWeights.map((w, i) => `${(i / (sortedWeights.length - 1)) * 300},${80 - ((w.weight - minW) / range) * 70 - 5}`).join(" ")}
                />
                {sortedWeights.map((w, i) => (
                  <circle key={i} cx={(i / (sortedWeights.length - 1)) * 300} cy={80 - ((w.weight - minW) / range) * 70 - 5} r="3" fill="var(--primary)" />
                ))}
              </svg>
              <div className="mt-2 flex justify-between text-xs text-muted-foreground">
                <span>{sortedWeights[0]?.weight} kg</span>
                <span>{sortedWeights[sortedWeights.length - 1]?.weight} kg</span>
              </div>
            </>
          )}
        </Card>

        {/* Period tabs */}
        <div className="flex gap-2 rounded-lg bg-card p-1">
          <button onClick={() => setPeriod("daily")} className={`flex-1 rounded-md px-3 py-1.5 text-sm font-medium transition ${period === "daily" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>Daily (7 days)</button>
          <button onClick={() => setPeriod("weekly")} className={`flex-1 rounded-md px-3 py-1.5 text-sm font-medium transition ${period === "weekly" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>Weekly (30 days)</button>
        </div>

        {/* Protein adherence */}
        <Card className="border-border bg-card p-4">
          <h3 className="font-bold">Protein — last {barCount} days</h3>
          <div className="mt-3 flex h-32 items-end gap-1">
            {bars.map((d, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-1">
                <div className="flex h-full w-full items-end overflow-hidden rounded-md bg-muted/40">
                  <div className="w-full rounded-md bg-gradient-to-t from-primary to-primary/60 transition-all" style={{ height: `${d.pct}%` }} />
                </div>
                {period === "daily" && (
                  <span className="text-[10px] text-muted-foreground">{new Date(d.date).toLocaleDateString("en", { weekday: "short" }).slice(0, 1)}</span>
                )}
              </div>
            ))}
          </div>
          <p className="mt-2 text-xs text-muted-foreground">Target: {target}g/day</p>
        </Card>

        {/* AI insights */}
        <Card className="border-border bg-card p-4">
          <div className="flex items-center justify-between">
            <h3 className="flex items-center gap-2 font-bold"><Sparkles className="h-4 w-4 text-primary" />{period === "daily" ? "Daily" : "Weekly"} insights</h3>
            <Button onClick={generateInsights} disabled={loading} size="sm" className="bg-primary text-primary-foreground hover:opacity-90">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : insights ? "Re-analyze" : "Analyze"}
            </Button>
          </div>
          {insightsAt && <p className="mt-1 text-[11px] text-muted-foreground">Saved · {new Date(insightsAt).toLocaleString()}</p>}
          {insights ? (
            <div className="mt-3 space-y-3 text-sm">
              <p className="font-semibold text-primary">{insights.headline}</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-md bg-muted/40 p-3 text-center">
                  <p className="text-xs text-muted-foreground">Adherence</p>
                  <p className="text-xl font-bold">{insights.adherencePct}%</p>
                </div>
                <div className="rounded-md bg-muted/40 p-3 text-center">
                  <p className="text-xs text-muted-foreground">Weight</p>
                  <p className="text-xl font-bold">{insights.weightChangeKg > 0 ? "+" : ""}{insights.weightChangeKg} kg</p>
                  <p className="text-xs text-muted-foreground capitalize">{insights.weightTrend}</p>
                </div>
              </div>
              {insights.wins?.map((w, i) => (
                <p key={i} className="flex items-start gap-2 text-xs"><CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />{w}</p>
              ))}
              {insights.warnings?.map((w, i) => (
                <p key={i} className="flex items-start gap-2 text-xs"><AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warning" />{w}</p>
              ))}
              {insights.nextActions?.length > 0 && (
                <div>
                  <p className="mb-1 text-xs font-medium text-muted-foreground">Next actions</p>
                  {insights.nextActions.map((a, i) => (
                    <p key={i} className="flex items-start gap-2 text-xs"><ArrowRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-accent" />{a}</p>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <p className="mt-3 text-sm text-muted-foreground">Tap Analyze for personalized {period === "daily" ? "daily (7-day)" : "weekly (30-day)"} insights from Gemini.</p>
          )}
        </Card>
        <p className="pt-4 text-center text-xs text-muted-foreground">AI Powered by Gemini</p>
      </main>
      <CoachChat />
      <BottomNav />
    </div>
  );
}
