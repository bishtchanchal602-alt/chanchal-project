import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { calcDailyCalories, calcDailyProtein, type Goal } from "@/lib/protein";
import { toast } from "sonner";
import { ArrowLeft, Loader2, LogOut, Save } from "lucide-react";
import { BottomNav } from "@/components/BottomNav";

export const Route = createFileRoute("/profile")({
  component: ProfilePage,
});

const GOALS: Goal[] = ["Stay Fit", "Build Muscle", "Bulking", "Lose Weight"];
const WORKOUT_TYPES = ["Weight Training", "Cardio", "HIIT", "Yoga", "Calisthenics", "Mixed"];
const WORKOUT_TIMES = ["Morning", "Afternoon", "Evening", "Night"];
const DURATIONS = ["30 min", "45 min", "60 min", "90 min+"];
const PROTEIN_PREFS = [
  { v: "Plant-Based", e: "🌱" }, { v: "Eggs", e: "🥚" }, { v: "Fish & Seafood", e: "🐟" },
  { v: "Chicken", e: "🍗" }, { v: "Red Meat", e: "🥩" }, { v: "Dairy", e: "🥛" },
  { v: "Grains & Legumes", e: "🌾" },
];
const COOK_TIMES = ["Under 10 min", "10–20 min", "20–40 min", "40+ min"];
const RESTRICTIONS = ["None", "Gluten-Free", "Lactose-Intolerant", "Diabetic"];

type Form = {
  full_name: string;
  age: number;
  sex: string;
  current_weight: number;
  target_weight: number;
  height: number;
  training_goal: Goal;
  workout_days: number;
  workout_duration: string;
  workout_types: string[];
  workout_time: string;
  protein_preferences: string[];
  daily_budget: number;
  max_cook_time: string;
  meals_per_day: number;
  dietary_restrictions: string[];
};

function ProfilePage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [email, setEmail] = useState<string>("");
  const [form, setForm] = useState<Form | null>(null);

  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { navigate({ to: "/auth" }); return; }
      setUserId(session.user.id);
      setEmail(session.user.email || "");
      const { data: p } = await supabase.from("profiles").select("*").eq("id", session.user.id).maybeSingle();
      if (p) {
        setForm({
          full_name: p.full_name || "",
          age: p.age || 25,
          sex: p.sex || "Male",
          current_weight: Number(p.current_weight) || 70,
          target_weight: Number(p.target_weight) || 75,
          height: Number(p.height) || 175,
          training_goal: (p.training_goal as Goal) || "Build Muscle",
          workout_days: p.workout_days || 4,
          workout_duration: p.workout_duration || "60 min",
          workout_types: p.workout_types || ["Weight Training"],
          workout_time: p.workout_time || "Evening",
          protein_preferences: p.protein_preferences || ["Eggs", "Chicken"],
          daily_budget: Number(p.daily_budget) || 200,
          max_cook_time: p.max_cook_time || "20–40 min",
          meals_per_day: p.meals_per_day || 4,
          dietary_restrictions: p.dietary_restrictions || ["None"],
        });
      }
      setLoading(false);
    })();
  }, [navigate]);

  const update = <K extends keyof Form>(k: K, v: Form[K]) =>
    setForm((f) => (f ? { ...f, [k]: v } : f));

  const toggleArr = (k: "workout_types" | "protein_preferences" | "dietary_restrictions", val: string) => {
    setForm((f) => {
      if (!f) return f;
      const arr = f[k];
      return { ...f, [k]: arr.includes(val) ? arr.filter((x) => x !== val) : [...arr, val] };
    });
  };

  const save = async () => {
    if (!userId || !form) return;
    setSaving(true);
    try {
      const dailyProtein = calcDailyProtein(form.current_weight, form.training_goal);
      const dailyCalories = calcDailyCalories(form.current_weight, form.training_goal);
      const proteinPerMeal = Math.round(dailyProtein / form.meals_per_day);
      const { error } = await supabase.from("profiles").update({
        ...form,
        daily_protein_target: dailyProtein,
        daily_calorie_target: dailyCalories,
        protein_per_meal: proteinPerMeal,
      }).eq("id", userId);
      if (error) throw error;
      toast.success("Profile updated! Targets recalculated.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to save");
    } finally {
      setSaving(false);
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  };

  if (loading || !form) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  const dailyProtein = calcDailyProtein(form.current_weight, form.training_goal);
  const dailyCalories = calcDailyCalories(form.current_weight, form.training_goal);

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-10 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
          <Link to="/dashboard" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Back
          </Link>
          <h1 className="text-lg font-bold">Profile</h1>
          <Button variant="ghost" size="sm" onClick={signOut} className="text-muted-foreground">
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-3xl space-y-4 px-4 pt-6">
        {/* Computed targets */}
        <Card className="border-primary/30 bg-primary/10 p-4">
          <p className="text-xs uppercase tracking-wide text-primary">Auto-calculated targets</p>
          <div className="mt-2 grid grid-cols-3 gap-3 text-center">
            <div><p className="text-2xl font-bold text-primary">{dailyProtein}g</p><p className="text-xs text-muted-foreground">Protein/day</p></div>
            <div><p className="text-2xl font-bold text-primary">{dailyCalories}</p><p className="text-xs text-muted-foreground">Calories/day</p></div>
            <div><p className="text-2xl font-bold text-primary">{Math.round(dailyProtein / form.meals_per_day)}g</p><p className="text-xs text-muted-foreground">Per meal</p></div>
          </div>
        </Card>

        {/* Account */}
        <Card className="border-border bg-card p-5">
          <h2 className="mb-4 text-base font-semibold">Account</h2>
          <div className="space-y-3">
            <div className="space-y-1.5"><Label>Email</Label><Input value={email} disabled /></div>
            <div className="space-y-1.5"><Label>Full name</Label><Input value={form.full_name} onChange={(e) => update("full_name", e.target.value)} /></div>
          </div>
        </Card>

        {/* Body */}
        <Card className="border-border bg-card p-5">
          <h2 className="mb-4 text-base font-semibold">Body</h2>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Age</Label><Input type="number" value={form.age} onChange={(e) => update("age", +e.target.value)} /></div>
            <div className="space-y-1.5">
              <Label>Sex</Label>
              <select value={form.sex} onChange={(e) => update("sex", e.target.value)} className="flex h-10 w-full rounded-md border border-input bg-input px-3 text-sm">
                <option>Male</option><option>Female</option><option>Prefer not to say</option>
              </select>
            </div>
            <div className="space-y-1.5"><Label>Current weight (kg)</Label><Input type="number" value={form.current_weight} onChange={(e) => update("current_weight", +e.target.value)} /></div>
            <div className="space-y-1.5"><Label>Target weight (kg)</Label><Input type="number" value={form.target_weight} onChange={(e) => update("target_weight", +e.target.value)} /></div>
            <div className="space-y-1.5 col-span-2"><Label>Height (cm)</Label><Input type="number" value={form.height} onChange={(e) => update("height", +e.target.value)} /></div>
          </div>
        </Card>

        {/* Goal */}
        <Card className="border-border bg-card p-5">
          <h2 className="mb-4 text-base font-semibold">Training goal</h2>
          <div className="grid grid-cols-2 gap-2">
            {GOALS.map((g) => (
              <button key={g} type="button" onClick={() => update("training_goal", g)} className={`rounded-md border py-2.5 text-sm font-medium transition ${form.training_goal === g ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/50"}`}>{g}</button>
            ))}
          </div>
        </Card>

        {/* Workouts */}
        <Card className="border-border bg-card p-5">
          <h2 className="mb-4 text-base font-semibold">Workouts</h2>
          <div className="space-y-4">
            <div>
              <div className="mb-2 flex justify-between"><Label>Days per week</Label><span className="font-bold text-primary">{form.workout_days}</span></div>
              <Slider value={[form.workout_days]} min={1} max={7} step={1} onValueChange={(v) => update("workout_days", v[0])} />
            </div>
            <div>
              <Label className="mb-2 block">Duration</Label>
              <div className="grid grid-cols-4 gap-2">
                {DURATIONS.map((d) => (
                  <button key={d} type="button" onClick={() => update("workout_duration", d)} className={`rounded-md border py-2 text-xs transition ${form.workout_duration === d ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/50"}`}>{d}</button>
                ))}
              </div>
            </div>
            <div>
              <Label className="mb-2 block">Types</Label>
              <div className="flex flex-wrap gap-2">
                {WORKOUT_TYPES.map((t) => (
                  <button key={t} type="button" onClick={() => toggleArr("workout_types", t)} className={`rounded-full border px-3 py-1.5 text-xs transition ${form.workout_types.includes(t) ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/50"}`}>{t}</button>
                ))}
              </div>
            </div>
            <div>
              <Label className="mb-2 block">Time of day</Label>
              <div className="grid grid-cols-4 gap-2">
                {WORKOUT_TIMES.map((t) => (
                  <button key={t} type="button" onClick={() => update("workout_time", t)} className={`rounded-md border py-2 text-xs transition ${form.workout_time === t ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/50"}`}>{t}</button>
                ))}
              </div>
            </div>
          </div>
        </Card>

        {/* Nutrition */}
        <Card className="border-border bg-card p-5">
          <h2 className="mb-4 text-base font-semibold">Nutrition preferences</h2>
          <div className="space-y-4">
            <div>
              <Label className="mb-2 block">Protein sources</Label>
              <div className="grid grid-cols-2 gap-2">
                {PROTEIN_PREFS.map((p) => (
                  <button key={p.v} type="button" onClick={() => toggleArr("protein_preferences", p.v)} className={`flex items-center gap-2 rounded-md border p-2.5 text-left text-sm transition ${form.protein_preferences.includes(p.v) ? "border-primary bg-primary/10" : "border-border bg-muted/50"}`}>
                    <span className="text-lg">{p.e}</span>{p.v}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <Label className="mb-2 block">Daily budget (₹)</Label>
              <Input type="number" value={form.daily_budget} onChange={(e) => update("daily_budget", +e.target.value)} />
            </div>
            <div>
              <Label className="mb-2 block">Max cook time</Label>
              <div className="grid grid-cols-2 gap-2">
                {COOK_TIMES.map((c) => (
                  <button key={c} type="button" onClick={() => update("max_cook_time", c)} className={`rounded-md border py-2 text-xs transition ${form.max_cook_time === c ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/50"}`}>{c}</button>
                ))}
              </div>
            </div>
            <div>
              <div className="mb-2 flex justify-between"><Label>Meals per day</Label><span className="font-bold text-primary">{form.meals_per_day}</span></div>
              <Slider value={[form.meals_per_day]} min={2} max={6} step={1} onValueChange={(v) => update("meals_per_day", v[0])} />
            </div>
            <div>
              <Label className="mb-2 block">Dietary restrictions</Label>
              <div className="flex flex-wrap gap-2">
                {RESTRICTIONS.map((r) => (
                  <label key={r} className="flex cursor-pointer items-center gap-2 rounded-md border border-border bg-muted/50 px-3 py-2 text-sm">
                    <Checkbox checked={form.dietary_restrictions.includes(r)} onCheckedChange={() => toggleArr("dietary_restrictions", r)} />
                    {r}
                  </label>
                ))}
              </div>
            </div>
          </div>
        </Card>

        <Button onClick={save} disabled={saving} className="w-full bg-primary text-primary-foreground hover:opacity-90" size="lg">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Save className="mr-2 h-4 w-4" /> Save changes</>}
        </Button>
      </main>

      <BottomNav />
    </div>
  );
}
